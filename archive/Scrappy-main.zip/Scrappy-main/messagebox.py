import subprocess
def showMSGBox(arg): subprocess.call(f'notepad vbs/{arg}.vbs', shell = True)
