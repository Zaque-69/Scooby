# SCRAPPY

Simple website file downloader 


<img width="1607" alt="webui" src="https://github.com/Zaque-69/scooby/blob/main/scrap.png">


#INPUTS :
* In the first black input, you need to insert a valid URL to a website or document online.;
* The 'Name' input is the name it will receive the folder with the files downloaded. If is empty, it will automatically get the website domain as name;
* The 'Search' input is related the the button with the same name. Simply insert an URL adress and it will be open in your browser.

#BUTTONS :
* SERVER BUTTON :  Click the button 'Servers' to choose a proxy server to change your location where the request will be sent from. Insert it in the next black input.;

The rest of the fields will be filled with information related to the downloaded website. Finally, press 'Run';
